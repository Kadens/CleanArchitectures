﻿using CleanArchitecture.Core.Entities;
using CleanArchitecture.SharedKernel;

namespace CleanArchitecture.Core.Events
{
    public class ToDoItemCompletedEvent : BaseDomainEvent
    {
        public ToDoItem CompletedItem { get; set; }

        public ToDoItemCompletedEvent(ToDoItem completedItem)
        {
            CompletedItem = completedItem;
        }
    }
}